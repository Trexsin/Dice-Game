#include <iostream>

using namespace std;

class Dice {
private:
    int face;
    int rollCount[6];
    int history[100];
    int totalRolls;

    // Simple pseudo-random number generator (no <cstdlib>)
    int simpleRandom() {
        static unsigned long seed = 123456789;
        seed = (1103515245 * seed + 12345) % 2147483648;
        return (seed % 6) + 1;
    }

public:
    Dice() {
        totalRolls = 0;
        for (int i = 0; i < 6; i++) rollCount[i] = 0;
    }

    int roll() {
        if (totalRolls >= 100) {
            cout << "Oops! You've reached the maximum roll history (100 rolls).\n";
            return -1;
        }

        face = simpleRandom();
        rollCount[face - 1]++;
        history[totalRolls++] = face;
        return face;
    }

    void showStats() const {
        cout << "\n📊 Dice Roll Summary:\n";
        for (int i = 0; i < 6; i++) {
            cout << " - Face " << (i + 1) << " rolled " << rollCount[i] << " time(s)\n";
        }
    }

    void showHistory() const {
        if (totalRolls == 0) {
            cout << "\n📜 No rolls yet! Try rolling the dice first.\n";
            return;
        }

        cout << "\n🧾 Roll History:\n";
        for (int i = 0; i < totalRolls; i++) {
            cout << " • Roll " << (i + 1) << ": 🎲 " << history[i] << endl;
        }
    }

    int getTotalRolls() const {
        return totalRolls;
    }
};

void showWelcomeMessage() {
    cout << "🎲 Welcome to the Friendly Dice Roller! 🎲\n";
    cout << "This little game simulates a fair 6-sided dice.\n";
    cout << "Track your rolls, view your history, and analyze your luck!\n";
}

void showMenu() {
    cout << "\n====== MENU ======\n";
    cout << "1. 🎲 Roll the Dice\n";
    cout << "2. 📜 View Roll History\n";
    cout << "3. 📊 View Statistics\n";
    cout << "4. 🚪 Exit\n";
    cout << "Choose an option (1-4): ";
}

int main() {
    Dice dice;
    int choice;

    showWelcomeMessage();

    do {
        showMenu();
        cin >> choice;

        switch (choice) {
            case 1: {
                int result = dice.roll();
                if (result != -1)
                    cout << "You rolled a 🎲 " << result << "! Let's go again!\n";
                break;
            }
            case 2:
                dice.showHistory();
                break;
            case 3:
                dice.showStats();
                break;
            case 4:
                cout << "\nThanks for playing! You rolled the dice " 
                     << dice.getTotalRolls() << " time(s).\n";
                cout << "May the odds be ever in your favor next time! 👋\n";
                break;
            default:
                cout << "❗ Invalid option. Please enter 1 to 4.\n";
        }

    } while (choice != 4);

    return 0;
}
