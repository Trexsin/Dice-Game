# 🎲 Friendly Dice Roller in C++

This is a console-based dice simulator written in C++ without external libraries like `<cstdlib>` or `<vector>`.

## Features
- Simulates a fair 6-sided dice
- Tracks roll history (up to 100 rolls)
- Shows face frequency statistics
- Friendly emoji-based UI and messages

## How to Run

### Compile:
```bash
g++ main.cpp -o dice_game
```

### Run:
```bash
./dice_game
```

## Project Structure

```
DiceRollerGame/
├── main.cpp
└── README.md
```
